const style = {
    color:{
        green :['#212121','#4CAF50','#00BC7B','#8BC34A','#C8E6C9'],
        blue  :['#212121','#0288D1','#486AFF','#03A9F4','#B3E5FC'],
        yellow:['#212121','#AFB42B','#F3D321','#FFEB3B','#F0F4C3'],
        orange:['#212121','#FF5722','#F6A04D','#EC7119','#FFEBCD'],
        purple:['#212121','#512DA8','#4D49BE','#E040FB','#D1C4E9'],
        red   :['#212121','#D32F2F','#F9423A','#FF5252','#FFCDD2'],
        bgc:'#FFEBCD',
    },
}
export default style;